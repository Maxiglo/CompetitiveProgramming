d=int(input())
l=int(input())
print(d+5*l)